export const BREAKPOINTS = {
	sm: 480,
	md: 768,
	lg: 1024,
	xlg: 1280,
}

export default BREAKPOINTS
