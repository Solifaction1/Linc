export const NAME_WEBSITE = 'Linc'
