import { ygwysCTA } from './attributes.model'

export default interface ColorBlockData {
	ctas: ygwysCTA[]
}
