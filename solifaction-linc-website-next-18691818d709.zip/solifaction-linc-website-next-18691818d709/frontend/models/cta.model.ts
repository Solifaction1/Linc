export default interface CTAData {
	id?: number
	title: string
	link: string
	externalLink: boolean
	buttonType: string
}
