export default interface VerticalListItemData {
    id: number,
    title: string | null,
}