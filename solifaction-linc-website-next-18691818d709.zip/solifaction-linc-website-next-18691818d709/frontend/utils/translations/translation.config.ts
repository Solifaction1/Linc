type translationsConfig = {
  en: {
    translation: {
      general: {
        showLess: string;
      };
    };
  };
  nl: {
    translation: {
      general: {
        showLess: string;
      };
    };
  };
  fr: {
    translation: {
      general: {
        showLess: string;
      };
    };
  };
};

export type { translationsConfig };
