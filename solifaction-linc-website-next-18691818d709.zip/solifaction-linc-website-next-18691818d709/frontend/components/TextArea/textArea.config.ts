type propsConfig = {
	label?: string
	onChange: any
	id?: string
}

const defaultProps = {}

export type { propsConfig }
export { defaultProps }
