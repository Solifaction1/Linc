type propsConfig = {
  videoSrcURL: string;
};

const defaultProps = {
  videoSrcURL: "https://www.youtube.com/watch?v=X13ocJRMEYI&list=RDX13ocJRMEYI",
};

export type { propsConfig };
export { defaultProps };
