import AccordionData from '@models/accordion.model'

const defaultProps: AccordionData = {
	title: 'title',
}

export { defaultProps }
