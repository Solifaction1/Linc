module.exports = {
    i18n: {
        localeDetection: false,
        defaultLocale: 'nl',
        locales: ['en', 'fr', 'nl'],
    },
};