'use strict';

/**
 * kantoor router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::kantoor.kantoor');
