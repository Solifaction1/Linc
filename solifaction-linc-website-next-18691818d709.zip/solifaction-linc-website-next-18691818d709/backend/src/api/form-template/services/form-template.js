'use strict';

/**
 * form-template service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::form-template.form-template');
