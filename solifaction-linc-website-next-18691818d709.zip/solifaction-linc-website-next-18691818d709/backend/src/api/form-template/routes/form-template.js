'use strict';

/**
 * form-template router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::form-template.form-template');
