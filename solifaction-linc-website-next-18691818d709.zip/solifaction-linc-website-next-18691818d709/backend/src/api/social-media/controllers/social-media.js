'use strict';

/**
 * social-media controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::social-media.social-media');
