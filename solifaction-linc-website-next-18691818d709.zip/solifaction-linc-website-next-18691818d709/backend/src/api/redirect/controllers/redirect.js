'use strict';

/**
 * redirect controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::redirect.redirect');
