'use strict';

/**
 * onze-rechtsdomeinen service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::onze-rechtsdomeinen.onze-rechtsdomeinen');
