'use strict';

/**
 * onze-rechtsdomeinen controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::onze-rechtsdomeinen.onze-rechtsdomeinen');
