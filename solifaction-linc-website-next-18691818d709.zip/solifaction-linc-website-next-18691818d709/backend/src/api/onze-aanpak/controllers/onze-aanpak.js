'use strict';

/**
 * onze-aanpak controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::onze-aanpak.onze-aanpak');
