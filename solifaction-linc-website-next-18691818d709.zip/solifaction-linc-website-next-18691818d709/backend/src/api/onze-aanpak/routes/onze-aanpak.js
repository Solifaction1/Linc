'use strict';

/**
 * onze-aanpak router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::onze-aanpak.onze-aanpak');
