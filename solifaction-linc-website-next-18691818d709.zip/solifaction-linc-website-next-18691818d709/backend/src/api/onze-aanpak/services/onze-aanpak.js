'use strict';

/**
 * onze-aanpak service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::onze-aanpak.onze-aanpak');
