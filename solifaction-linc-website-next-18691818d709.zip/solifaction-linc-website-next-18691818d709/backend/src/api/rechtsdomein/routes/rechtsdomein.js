'use strict';

/**
 * rechtsdomein router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::rechtsdomein.rechtsdomein');
