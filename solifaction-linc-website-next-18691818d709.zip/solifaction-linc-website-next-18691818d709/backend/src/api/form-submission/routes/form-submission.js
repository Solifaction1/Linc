'use strict';

/**
 * form-submission router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::form-submission.form-submission');
