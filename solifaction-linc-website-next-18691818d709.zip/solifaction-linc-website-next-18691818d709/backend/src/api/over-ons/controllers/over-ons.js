'use strict';

/**
 * over-ons controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::over-ons.over-ons');
