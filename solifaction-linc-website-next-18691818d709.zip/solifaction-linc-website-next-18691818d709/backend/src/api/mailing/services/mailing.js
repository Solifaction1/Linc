'use strict';

/**
 * email service.
 */

module.exports = () => ({});
