'use strict';

const myController = require('./my-controller');

module.exports = {
  myController,
};
