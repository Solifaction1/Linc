'use strict';

const myService = require('./my-service');

module.exports = {
  myService,
};
