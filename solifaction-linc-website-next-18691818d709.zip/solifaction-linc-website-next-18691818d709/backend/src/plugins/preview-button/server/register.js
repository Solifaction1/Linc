'use strict';

module.exports = ({ strapi }) => {
  // registeration phase
};
