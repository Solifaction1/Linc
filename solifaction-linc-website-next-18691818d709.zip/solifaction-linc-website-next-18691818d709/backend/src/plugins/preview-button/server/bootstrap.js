'use strict';

module.exports = ({ strapi }) => {
  // bootstrap phase
};
