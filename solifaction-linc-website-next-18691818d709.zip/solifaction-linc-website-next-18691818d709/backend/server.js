const strapi = require('@strapi/strapi');

strapi(/* {...} */).start();
